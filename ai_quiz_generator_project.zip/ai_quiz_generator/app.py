import os
import re
import json
import time
import hmac
import sqlite3
from datetime import datetime
from pathlib import Path

import fitz
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI

# ---------------- CONFIGURATION ----------------
load_dotenv()
st.set_page_config(page_title="AI Quiz Generator", page_icon="📝", layout="wide")

DB_NAME = os.getenv("QUIZ_DB_PATH", "quiz_results.db")
MODEL_NAME = os.getenv("OPENAI_MODEL", "gpt-5.5")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")
MAX_NOTE_CHARS = 50000
Path("uploaded_notes").mkdir(exist_ok=True)


# ---------------- DATABASE ----------------
def get_connection():
    conn = sqlite3.connect(DB_NAME, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_connection() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            title TEXT NOT NULL,
            filename TEXT NOT NULL,
            extracted_text TEXT NOT NULL,
            uploaded_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            subject TEXT NOT NULL,
            questions_json TEXT NOT NULL,
            material_ids TEXT NOT NULL,
            duration_minutes INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            exam_id INTEGER NOT NULL,
            score INTEGER NOT NULL,
            total INTEGER NOT NULL,
            percentage REAL NOT NULL,
            answers_json TEXT NOT NULL,
            submitted_at TEXT NOT NULL,
            FOREIGN KEY (exam_id) REFERENCES exams(id)
        );
        """)


def save_material(subject, title, filename, extracted_text):
    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO materials(subject,title,filename,extracted_text,uploaded_at)
               VALUES(?,?,?,?,?)""",
            (subject, title, filename, extracted_text,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        return cur.lastrowid


def get_materials(subject=None):
    with get_connection() as conn:
        if subject:
            rows = conn.execute(
                "SELECT id, subject, title, filename, uploaded_at FROM materials WHERE subject=? ORDER BY uploaded_at DESC",
                (subject,)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, subject, title, filename, uploaded_at FROM materials ORDER BY subject, title"
            ).fetchall()
    return [dict(r) for r in rows]


def get_material_text(material_ids):
    if not material_ids:
        return []
    placeholders = ",".join("?" for _ in material_ids)
    with get_connection() as conn:
        rows = conn.execute(
            f"SELECT id, subject, title, extracted_text FROM materials WHERE id IN ({placeholders})",
            tuple(material_ids)
        ).fetchall()
    # Preserve the order selected by the admin
    by_id = {int(row["id"]): dict(row) for row in rows}
    return [by_id[mid] for mid in material_ids if mid in by_id]


def create_exam(title, subject, questions, material_ids, duration_minutes):
    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO exams(title,subject,questions_json,material_ids,duration_minutes,created_at)
               VALUES(?,?,?,?,?,?)""",
            (title.strip(), subject, json.dumps(questions), json.dumps(material_ids),
             int(duration_minutes), datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        return cur.lastrowid


def get_exams():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id,title,subject,duration_minutes,created_at FROM exams ORDER BY id DESC"
        ).fetchall()
    return [dict(r) for r in rows]


def get_exam(exam_id):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM exams WHERE id=?", (int(exam_id),)).fetchone()
    return dict(row) if row else None


def save_result(student_name, exam_id, score, total, answers):
    percentage = round(score / total * 100, 2) if total else 0.0
    submitted_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO results(student_name,exam_id,score,total,percentage,answers_json,submitted_at)
               VALUES(?,?,?,?,?,?,?)""",
            (student_name.strip(), int(exam_id), int(score), int(total), percentage,
             json.dumps(answers), submitted_at)
        )
        result_id = cur.lastrowid
    return {
        "id": result_id, "student_name": student_name.strip(), "exam_id": int(exam_id),
        "score": int(score), "total": int(total), "percentage": percentage,
        "answers": answers, "submitted_at": submitted_at
    }


def get_exam_results(exam_id):
    with get_connection() as conn:
        rows = conn.execute(
            """SELECT r.id, r.student_name, r.exam_id, r.score, r.total, r.percentage,
                      r.answers_json, r.submitted_at, e.title AS exam_title, e.subject
               FROM results r JOIN exams e ON e.id=r.exam_id
               WHERE r.exam_id=?
               ORDER BY r.percentage DESC, r.score DESC, r.submitted_at ASC""",
            (int(exam_id),)
        ).fetchall()
    return [dict(r) for r in rows]


def get_all_results():
    with get_connection() as conn:
        rows = conn.execute(
            """SELECT r.id, r.student_name, r.exam_id, r.score, r.total, r.percentage,
                      r.submitted_at, e.title AS exam_title, e.subject
               FROM results r JOIN exams e ON e.id=r.exam_id
               ORDER BY e.id DESC, r.percentage DESC, r.score DESC"""
        ).fetchall()
    return [dict(r) for r in rows]


init_db()


# ---------------- PDF/TXT EXTRACTION ----------------
def extract_text(uploaded_file):
    name = uploaded_file.name.lower()
    data = uploaded_file.getvalue()
    if name.endswith(".pdf"):
        with fitz.open(stream=data, filetype="pdf") as document:
            return "\n".join(page.get_text("text") for page in document).strip()
    if name.endswith(".txt"):
        return data.decode("utf-8", errors="ignore").strip()
    raise ValueError("Only PDF and TXT files are supported.")


# ---------------- REAL AI QUESTION GENERATION ----------------
def generate_ai_questions(notes, number):
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is missing. Add your API key to the .env file and restart Streamlit."
        )

    # Limit request size to keep costs and latency manageable.
    source_text = notes[:MAX_NOTE_CHARS]
    client = OpenAI(api_key=api_key, timeout=90.0, max_retries=2)

    instructions = (
        "You create accurate educational multiple-choice questions using ONLY the supplied study notes. "
        "Do not use outside facts. Return valid JSON only, no markdown. "
        "The JSON must have one key named questions containing an array. "
        "Each question object must have: question (string), options (array of exactly four distinct strings), "
        "answer (string matching one option exactly), explanation (short string explaining the answer). "
        "Avoid trick questions and duplicate questions. If the notes do not support enough questions, "
        "return only the questions that can be supported."
    )
    prompt = (
        f"Create up to {number} multiple-choice questions from these study notes. "
        "Keep questions suitable for a college student. Ensure the correct answer is supported by the notes.\n\n"
        f"STUDY NOTES:\n{source_text}"
    )

    response = client.responses.create(
        model=MODEL_NAME,
        instructions=instructions,
        input=prompt,
        text={"format": {"type": "json_object"}}
    )
    raw = response.output_text.strip()
    # Tolerate a code fence in case a model returns one despite instructions.
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE)
    data = json.loads(raw)
    questions = data.get("questions", [])
    cleaned = []
    for item in questions:
        if not isinstance(item, dict):
            continue
        question = str(item.get("question", "")).strip()
        options = item.get("options", [])
        answer = str(item.get("answer", "")).strip()
        explanation = str(item.get("explanation", "")).strip()
        if not question or not isinstance(options, list):
            continue
        options = [str(x).strip() for x in options if str(x).strip()]
        # Preserve order while removing duplicate choices.
        options = list(dict.fromkeys(options))
        if len(options) != 4 or answer not in options:
            continue
        cleaned.append({
            "question": question,
            "options": options,
            "answer": answer,
            "explanation": explanation or "Review the selected study notes for this concept."
        })
        if len(cleaned) >= number:
            break
    if len(cleaned) < 3:
        raise ValueError(
            "The AI returned fewer than 3 valid questions. Upload longer, text-based notes or try a different selection."
        )
    return cleaned


# ---------------- SESSION HELPERS ----------------
def clear_exam_session():
    for key in ["active_exam_id", "active_exam_title", "active_student", "active_questions",
                "active_answers", "exam_deadline", "active_result", "exam_submitted"]:
        st.session_state.pop(key, None)


def finish_exam(auto_submitted=False):
    if st.session_state.get("exam_submitted"):
        return
    questions = st.session_state.get("active_questions", [])
    answers = st.session_state.get("active_answers", {})
    score = sum(
        1 for i, q in enumerate(questions)
        if answers.get(str(i)) == q["answer"]
    )
    result = save_result(
        st.session_state["active_student"],
        st.session_state["active_exam_id"],
        score,
        len(questions),
        answers
    )
    result["auto_submitted"] = auto_submitted
    st.session_state.active_result = result
    st.session_state.exam_submitted = True


def is_admin_logged_in():
    return bool(st.session_state.get("admin_logged_in"))


# ---------------- HEADER ----------------
st.title("📝 AI Quiz Generator from Study Notes")
st.caption("Upload study material, generate AI-powered exams, assess students, and download results.")
tabs = st.tabs(["🔐 Admin", "🧑‍🎓 Student Exams", "🏆 Leaderboards & Reports"])


# ---------------- TAB 1: ADMIN ----------------
with tabs[0]:
    st.header("Admin dashboard")
    if not is_admin_logged_in():
        st.info("Sign in to manage study materials and create exams.")
        with st.form("admin_login_form"):
            username = st.text_input("Admin username")
            password = st.text_input("Admin password", type="password")
            login_clicked = st.form_submit_button("Log in", type="primary")
        if login_clicked:
            if not ADMIN_PASSWORD:
                st.error("Admin password is not configured. Add ADMIN_PASSWORD to your .env file and restart the app.")
            elif hmac.compare_digest(username.strip(), ADMIN_USERNAME) and hmac.compare_digest(password, ADMIN_PASSWORD):
                st.session_state.admin_logged_in = True
                st.success("Admin login successful.")
                st.rerun()
            else:
                st.error("Incorrect username or password.")
    else:
        top1, top2 = st.columns([4, 1])
        top1.success(f"Logged in as {ADMIN_USERNAME}")
        if top2.button("Log out"):
            st.session_state.admin_logged_in = False
            st.rerun()

        upload_tab, create_tab, materials_tab, admin_results_tab = st.tabs(
            ["Upload notes", "Create exam", "Study library", "All results"]
        )

        with upload_tab:
            st.subheader("Upload multiple study PDFs/TXT files")
            subject = st.selectbox(
                "Subject category",
                ["Python", "DBMS", "Artificial Intelligence", "Web Development", "Java", "Computer Networks", "Other"],
                key="upload_subject"
            )
            custom_subject = st.text_input("Custom subject (optional)", key="custom_subject")
            if subject == "Other" and custom_subject.strip():
                subject = custom_subject.strip()
            files = st.file_uploader(
                "Choose multiple PDF or TXT files",
                type=["pdf", "txt"],
                accept_multiple_files=True,
                key="multiple_material_upload"
            )
            if files:
                st.caption(f"{len(files)} file(s) selected.")
                if st.button("Save selected study materials", type="primary"):
                    saved, skipped = 0, []
                    for file in files:
                        try:
                            text_content = extract_text(file)
                            if not text_content.strip():
                                skipped.append(f"{file.name}: no readable text (scanned PDFs may need OCR).")
                                continue
                            title = Path(file.name).stem.replace("_", " ").strip() or file.name
                            save_material(subject, title, file.name, text_content)
                            saved += 1
                        except Exception as exc:
                            skipped.append(f"{file.name}: {exc}")
                    if saved:
                        st.success(f"Saved {saved} study material(s) under {subject}.")
                    for message in skipped:
                        st.warning(message)
                    st.rerun()
            st.caption("Text-based PDFs and TXT files are supported. Scanned/image-only PDFs need OCR before their text can be used.")

        with create_tab:
            st.subheader("Create an exam from selected study materials")
            materials = get_materials()
            if not materials:
                st.info("Upload at least one study material first.")
            else:
                subject_options = sorted(set(m["subject"] for m in materials))
                chosen_subject = st.selectbox("Choose subject", subject_options, key="exam_subject")
                subject_materials = [m for m in materials if m["subject"] == chosen_subject]
                material_labels = {
                    f'{m["title"]} — {m["filename"]} (ID {m["id"]})': m["id"]
                    for m in subject_materials
                }
                chosen_labels = st.multiselect(
                    "Select one or more PDFs/TXT files for this exam",
                    list(material_labels.keys()),
                    key="exam_materials"
                )
                col_a, col_b, col_c = st.columns(3)
                with col_a:
                    exam_title = st.text_input("Exam title", placeholder="e.g. Python Unit Test 1")
                with col_b:
                    question_count = st.slider("Number of questions", 3, 25, 10)
                with col_c:
                    duration = st.slider("Duration (minutes)", 1, 90, 15)

                if st.button("Generate AI exam", type="primary"):
                    if not exam_title.strip():
                        st.warning("Enter an exam title.")
                    elif not chosen_labels:
                        st.warning("Select at least one study material.")
                    else:
                        ids = [material_labels[label] for label in chosen_labels]
                        selected_materials = get_material_text(ids)
                        combined_notes = "\n\n".join(
                            f"STUDY MATERIAL: {m['title']}\n{m['extracted_text']}"
                            for m in selected_materials
                        )
                        if len(combined_notes.strip()) < 100:
                            st.error("The selected materials contain too little readable text.")
                        else:
                            try:
                                with st.spinner("Generating questions with the AI model..."):
                                    questions = generate_ai_questions(combined_notes, question_count)
                                exam_id = create_exam(
                                    exam_title, chosen_subject, questions, ids, duration
                                )
                                st.success(f"Exam created successfully! Exam ID: {exam_id}. Students can now see it in Student Exams.")
                                st.write(f"Valid questions created: **{len(questions)}**")
                                with st.expander("Preview generated questions"):
                                    for i, q in enumerate(questions, 1):
                                        st.markdown(f"**Q{i}. {q['question']}**")
                                        st.write("Options: " + " | ".join(q["options"]))
                                        st.write("Correct answer: " + q["answer"])
                            except Exception as exc:
                                st.error(f"Could not generate the exam: {exc}")
                                st.caption("Check that your API key, model name, account access, and API billing/limits are configured.")

        with materials_tab:
            st.subheader("Subject-wise study material library")
            all_materials = get_materials()
            if all_materials:
                filter_subject = st.selectbox(
                    "Filter by subject",
                    ["All subjects"] + sorted(set(m["subject"] for m in all_materials)),
                    key="library_filter"
                )
                visible = all_materials if filter_subject == "All subjects" else [
                    m for m in all_materials if m["subject"] == filter_subject
                ]
                st.dataframe(pd.DataFrame(visible), use_container_width=True, hide_index=True)
                # Show stored note text for review without exposing it on the student exam page.
                label_to_id = {f'{m["title"]} — {m["filename"]} (ID {m["id"]})': m["id"] for m in visible}
                if label_to_id:
                    selected_label = st.selectbox("Preview extracted text", list(label_to_id), key="preview_material")
                    preview_id = label_to_id[selected_label]
                    preview = get_material_text([preview_id])
                    if preview:
                        st.text_area("Extracted text preview", preview[0]["extracted_text"][:5000], height=180, disabled=True)
            else:
                st.info("No study materials have been uploaded yet.")

        with admin_results_tab:
            st.subheader("All student attempts")
            all_results = get_all_results()
            if all_results:
                df = pd.DataFrame(all_results)
                st.dataframe(df, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download all results as CSV",
                    df.to_csv(index=False).encode("utf-8-sig"),
                    file_name="all_quiz_results.csv",
                    mime="text/csv"
                )
            else:
                st.info("No results have been submitted yet.")


# ---------------- TAB 2: STUDENT EXAMS ----------------
with tabs[1]:
    st.header("Student examination area")
    if st.session_state.get("exam_submitted") and st.session_state.get("active_result"):
        result = st.session_state.active_result
        exam = get_exam(result["exam_id"])
        st.success("Exam submitted successfully." + (" Time expired; answers were submitted automatically." if result.get("auto_submitted") else ""))
        st.subheader(f"Result: {exam['title'] if exam else 'Exam'}")
        m1, m2, m3 = st.columns(3)
        m1.metric("Marks", f"{result['score']}/{result['total']}")
        m2.metric("Percentage", f"{result['percentage']:.2f}%")
        m3.metric("Incorrect / unanswered", result["total"] - result["score"])
        if result["percentage"] >= 80:
            st.success("Excellent performance!")
        elif result["percentage"] >= 50:
            st.info("Good effort. Review the feedback below.")
        else:
            st.warning("Keep practising and review the study material.")
        st.subheader("Detailed feedback")
        questions = st.session_state.get("active_questions", [])
        for i, q in enumerate(questions):
            selected = result["answers"].get(str(i), "(Not answered)")
            if selected == q["answer"]:
                st.success(f"Q{i + 1}. Correct — {q['answer']}")
            else:
                st.error(f"Q{i + 1}. Your answer: {selected} | Correct answer: {q['answer']}")
            if q.get("explanation"):
                st.caption(q["explanation"])
        result_csv = pd.DataFrame([{
            "Student": result["student_name"],
            "Exam": exam["title"] if exam else "",
            "Subject": exam["subject"] if exam else "",
            "Marks": f"{result['score']}/{result['total']}",
            "Percentage": result["percentage"],
            "Submitted at": result["submitted_at"]
        }])
        st.download_button(
            "Download my result CSV",
            result_csv.to_csv(index=False).encode("utf-8-sig"),
            file_name=f"result_{result['id']}.csv",
            mime="text/csv"
        )
        if st.button("Return to exam list"):
            clear_exam_session()
            st.rerun()

    elif st.session_state.get("active_exam_id") and st.session_state.get("active_questions"):
        # Fragment refreshes the countdown independently; on expiry it records the attempt.
        @st.fragment(run_every="1s")
        def running_exam():
            if st.session_state.get("exam_submitted"):
                st.rerun(scope="app")
                return
            deadline = st.session_state.get("exam_deadline", time.time())
            seconds_left = max(0, int(deadline - time.time()))
            st.subheader(st.session_state.active_exam_title)
            st.write(f"Student: **{st.session_state.active_student}**")
            st.warning(f"Time remaining: **{seconds_left // 60:02d}:{seconds_left % 60:02d}**")
            if seconds_left <= 0:
                finish_exam(auto_submitted=True)
                st.rerun(scope="app")
                return

            questions = st.session_state.active_questions
            for i, q in enumerate(questions):
                st.markdown(f"**Question {i + 1}: {q['question']}**")
                selected = st.radio(
                    "Choose an answer",
                    q["options"],
                    index=q["options"].index(st.session_state.active_answers[str(i)])
                    if st.session_state.active_answers.get(str(i)) in q["options"] else None,
                    key=f"exam_{st.session_state.active_exam_id}_answer_{i}",
                    label_visibility="collapsed"
                )
                st.session_state.active_answers[str(i)] = selected

            if st.button("Submit exam now", type="primary", key="submit_active_exam"):
                finish_exam(auto_submitted=False)
                st.rerun(scope="app")

        running_exam()

    else:
        exams = get_exams()
        if not exams:
            st.info("No exams are available yet. Ask the admin to create an exam.")
        else:
            exam_options = {
                f'{e["title"]} — {e["subject"]} — {e["duration_minutes"]} min (Exam ID {e["id"]})': e["id"]
                for e in exams
            }
            selected_exam_label = st.selectbox("Choose an exam", list(exam_options), key="student_exam_choice")
            student_name = st.text_input("Enter your name", placeholder="e.g. Sukanya", key="student_name_input")
            if st.button("Start exam", type="primary"):
                exam_id = exam_options[selected_exam_label]
                exam = get_exam(exam_id)
                if not student_name.strip():
                    st.warning("Please enter your name.")
                elif not exam:
                    st.error("This exam could not be found.")
                else:
                    questions = json.loads(exam["questions_json"])
                    st.session_state.active_exam_id = exam_id
                    st.session_state.active_exam_title = exam["title"]
                    st.session_state.active_student = student_name.strip()
                    st.session_state.active_questions = questions
                    st.session_state.active_answers = {}
                    st.session_state.exam_deadline = time.time() + int(exam["duration_minutes"]) * 60
                    st.session_state.exam_submitted = False
                    st.session_state.pop("active_result", None)
                    st.rerun()


# ---------------- TAB 3: LEADERBOARDS & REPORTS ----------------
with tabs[2]:
    st.header("Exam-wise leaderboard and reports")
    exams = get_exams()
    if not exams:
        st.info("No exams exist yet.")
    else:
        exam_map = {
            f'{e["title"]} — {e["subject"]} (Exam ID {e["id"]})': e["id"]
            for e in exams
        }
        selected_label = st.selectbox("Select exam for leaderboard", list(exam_map), key="leaderboard_exam")
        selected_id = exam_map[selected_label]
        rows = get_exam_results(selected_id)
        if not rows:
            st.info("No students have completed this exam yet.")
        else:
            # Keep each student's best attempt for this exam; ties share rank.
            best_by_student = {}
            for row in rows:  # already ordered by percentage, score, then submission time
                key = row["student_name"].strip().casefold()
                if key not in best_by_student:
                    best_by_student[key] = row
            best_rows = list(best_by_student.values())
            best_rows.sort(key=lambda r: (-r["percentage"], -r["score"], r["submitted_at"], r["student_name"].casefold()))
            leaderboard = []
            last_pair = None
            rank = 0
            for position, row in enumerate(best_rows, start=1):
                pair = (row["percentage"], row["score"])
                if pair != last_pair:
                    rank = position
                leaderboard.append({
                    "Rank": rank,
                    "Student": row["student_name"],
                    "Marks": f'{row["score"]}/{row["total"]}',
                    "Percentage": f'{row["percentage"]:.2f}%',
                    "Submitted at": row["submitted_at"]
                })
                last_pair = pair
            st.dataframe(pd.DataFrame(leaderboard), use_container_width=True, hide_index=True)
            st.download_button(
                "Download this exam's leaderboard CSV",
                pd.DataFrame(leaderboard).to_csv(index=False).encode("utf-8-sig"),
                file_name=f"leaderboard_exam_{selected_id}.csv",
                mime="text/csv"
            )

        st.subheader("All attempts for selected exam")
        if rows:
            attempts_df = pd.DataFrame([{
                "Student": r["student_name"],
                "Exam": r["exam_title"],
                "Subject": r["subject"],
                "Marks": f'{r["score"]}/{r["total"]}',
                "Percentage": f'{r["percentage"]:.2f}%',
                "Submitted at": r["submitted_at"]
            } for r in rows])
            st.dataframe(attempts_df, use_container_width=True, hide_index=True)
            st.download_button(
                "Download all attempts for this exam",
                attempts_df.to_csv(index=False).encode("utf-8-sig"),
                file_name=f"attempts_exam_{selected_id}.csv",
                mime="text/csv"
            )

st.divider()
st.caption("Student names are not verified identities. For a real examination, add student accounts, attempt limits, and server-side access controls.")
